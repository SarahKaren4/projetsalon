Produced by : BlueLife � velociraptor
www.sordum.org

##########  Windows Update Blocker v1.2  ##################
Release date: April 21, 2019

1. [ ADDED ] - GUI option for services which added to Ini
2. [ FIXED ] - Some Parts of the software recoded (Improved)

##########  Windows Update Blocker v1.1  ##################
Release date: May 06, 2018

1. [ ADDED ] - Language support
2. [ ADDED ] - An option to add different services from Ini file. DoSvc sevice attached
3. [ FIXED ] - Some minor BUGS


##########  Windows Update Blocker v1.0  ##################
Release date: December 6, 2016

Windows Update Blocker is a freeware that helps you to completely disable or enable Automatic Updates on 
your Windows system , with just a click of the button 


